# README

这里放置了一些模板中用到了图片素材。素材来源如下：

1. [中山大学视觉形象识别系统](http://home3.sysu.edu.cn/sysuvi/content/)
